const popupBtnOpen = document.querySelector(".right ul li a");
const popupCont = document.querySelector(".login__popup");
const popupBtnClose = document.querySelector(".btn-close");

popupBtnOpen.addEventListener("click", () => {
  popupCont.classList.add("open");
});

popupBtnClose.addEventListener("click", () => {
  popupCont.classList.remove("open");
});
