<footer id="footer">
        <h2>푸터 영역입니다.</h2>
        <div class="footer__inner container">
            <address>Copyright @2022 webstoryboy</address>
            <div>blog by webstoryboy</div>
        </div>
    </footer>
    <!-- footer -->