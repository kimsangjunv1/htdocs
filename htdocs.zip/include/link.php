<!-- STYLE -->
<link rel="stylesheet" href="../assets/css/style.min.css">

<!-- SEO 포폴때 참고 -->
<meta name="author" content="codi">
<meta name="description" content="사이트 만들기 연습해보기!">
<meta name="keyword" content="사이트, 만들기, 튜토리얼, 웹스토리보이">
<meta name="robots" content="all">

<!-- ICON -->
<link rel="icon" href="../assets/img/icon_256.png" />
<link rel="shortcut icon" href="../assets/img/favicon.ico" />
<link rel="icon" type="image/png" sizes="256x256" href="../assets/img/icon_256.png" />
<link rel="icon" type="image/png" sizes="192x192" href="../assets/img/icon_192.png" />
<link rel="icon" type="image/png" sizes="32x32" href="../assets/img/icon_32.png" />
<link rel="icon" type="image/png" sizes="16x16" href="../assets/img/icon_16.png" />